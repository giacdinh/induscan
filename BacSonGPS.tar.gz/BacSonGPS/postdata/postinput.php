<?php
date_default_timezone_set("America/New_York");
$servername = "sql182.main-hosting.eu";
$database = "u426042465_test";
$username = "u426042465_xin";
$password = "anhbacson2";
$conn = new mysqli($servername, $username, $password, $database);
$inc = array();
$inc = array_merge($inc, $_POST);
$inc = array_merge($inc, $_GET);

// Check connection

if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

$now = time();

// $logReceived = date('H:i:s m/d/Y', $now) . "\tDevice ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . "\tTemp: " . $inc['temp'] . "\n";
// file_put_contents("/dukeenergy/Log/ReceivedRequestLog.txt", $logReceived, FILE_APPEND | LOCK_EX);

$coord = $inc['coord'];
$uid = $inc['uid'];
$fwv = $inc['fwv'];
$temperature = convertToFahrenheit(explode("'C", $inc['temp'])[0]);

$temp = explode(", ", $coord);
$latitude = $temp[0];
$longtitude = $temp[1];
$status = '';
$lastReport = '';
$tableCode = explode("_", $uid);
switch($tableCode[0]){
	case "de":
		$table = "de-devices";
		break;
	default:
		exit('Table name not available');
}


$result = $conn->query("SELECT * FROM `{$table}` WHERE unitID = '$uid'");

if (mysqli_num_rows($result) == 0) { //not exist, create new record
    $lastReport = date('H:i:s m/d/Y', $now);
	//echo "Not exist, attempt to insert new record";
	
	$sql = "INSERT INTO `{$table}` (unitID, toolWatch, firmwareVersion, latitude, longtitude, temperature, lastReport) VALUES ('$uid', 'Device 1', '$fwv', '$latitude', '$longtitude', '$temperature', '$now')";
	if (mysqli_query($conn, $sql)) {
		//echo "Records inserted successfully.";
		http_response_code(206);
	} else {
		//echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
		http_response_code(500);
	}
} else { //existed, update record
	//echo "exist";
	$result = $conn->query("SELECT lastReport FROM `{$table}` WHERE unitID = '$uid'");
	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		$lastReport = $row['lastReport'];
	} else {
		//echo 'Field does not exist';
		http_response_code(500);
	}
	$query = $conn->query("UPDATE `{$table}` SET firmwareVersion='$fwv', latitude='$latitude', longtitude='$longtitude', temperature='$temperature', lastReport='$now' WHERE unitID = '$uid'");
	if($query){
		//echo 'Update uid: ' . $uid . ' successful'; 
		http_response_code(206);
	}else{
	    //echo 'Update uid: ' . $uid . ' not successful'; 
		http_response_code(500);
	}
}

//Send email
ini_set('display_errors', 1);
error_reporting(E_ALL);
$from = "bacsonteam@bacson.tech";
$to = "ghecu@hotmail.com";
$subject = "Power pack device status report";
$address = getaddress($latitude, $longtitude);

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Create email headers
$headers .= 'From: ' . $from . "\r\n" .
    'Reply-To: ' . $from . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

$message = '<html><body>';
$message .= '<p style="color:#3498DB;font-size:18px;">Device: ' . $uid . '</p>';
$message .= '<p style="color:#3498DB;font-size:18px;">Firmware Version: ' . $fwv . '</p>';
$message .= '<p style="color:#3498DB;font-size:18px;">Location: <a href="https://www.google.com/maps/search/?api=1&query=' . $address . '" style="color:#3498DB;font-size:18px;">' . $address . '</a></p>';
$message .= '<p style="color:#3498DB;font-size:18px;">Coordinate: <a href="https://www.google.com/maps/search/?api=1&query=' . $latitude . ',' . $longtitude . '" style="color:#3498DB;font-size:18px;">' . $latitude . ', ' . $longtitude . '</a></p>';
$message .= '<p style="color:#3498DB;font-size:18px;">Last report: ' . date('H:i:s m/d/Y', $now) . '</p>';
$message .= '<p style="color:#3498DB;font-size:18px;">Temperature: ' . $temperature . ' &#176;F</p>';
$message .= '<h1 style="color:#C70039;">From: Bac Son Tech LLC</h1>';
$message .= '</body></html>';

if (mail($to, $subject, $message, $headers)) {
	mail("cusinbs@gmail.com", $subject, $message, $headers);
	$logSendEmail = date('H:i:s m/d/Y', $now) . "\tDevice ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . "\tTemp: " . $inc['temp'] . "\tEmail Status: Sent\n";
	//echo 'Your mail has been sent successfully.';
	http_response_code(200);
} else {
	$logSendEmail = date('H:i:s m/d/Y', $now) . "\tDevice ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . "\tTemp: " . $inc['temp'] . "\tEmail Status: Not Sent\n";
	//echo 'Unable to send email. Please try again.';
	http_response_code(503);
}
//file_put_contents("/dukeenergy/Log/EmailSentLog.txt", $logSendEmail, FILE_APPEND | LOCK_EX);

function getaddress($lat, $lng)
{
    $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat) . ',' . trim($lng) . '&key=AIzaSyCieFL8z1Dsu6r7aIhkOaNB-mMmGlxCjAE';
    $json = @file_get_contents($url);
    $data = json_decode($json);
    $status = $data->status;
    if ($status == "OK") {
        return $data->results[0]->formatted_address;
    } else {
        return 'Not found';
    }
}

function convertToFahrenheit($temperature){
	$temp = (float) $temperature;
	return $temp * 1.8 + 32;
}


$conn->close();
