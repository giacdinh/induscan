@extends('layouts.app')

@section('content')

<style>
    #bottom-stuff {

        position: relative;
    }

    #bottom {

        position: fixed;
        background: gray;
        width: 100%;
        bottom: 0;
    }

    #search {
        height: 5000px;
        overflow-y: scroll;
    }
</style>

@php //add address field into the devices object array
    foreach($devices as $device){
        $device->serial .= ' @ ' . $device->address;
    }
@endphp

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <center><div id="map" style="width: 100%; height: 600px;"></div></center>
        </div>
    </div>
</div>

<script src="http://maps.google.com/maps/api/js?key=AIzaSyDy-rj-7eYIXR5Tb9xA5YjyTgNwng6LIaE&sensor=false" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {

        var deviceInfos = {!! json_encode($devices) !!};
        var group = {!! json_encode($group) !!};
        var user = {!! json_encode($currentUser) !!};
        var locations= [];
        for(var i = 0; i < deviceInfos.length; i++){
            locations.push([deviceInfos[i].serial, deviceInfos[i].latitude, deviceInfos[i].longtitude]);
        }
        var latitude, longtitude;
        if(user.id === 3){
            latitude = 28.4456;
            longtitude = -81.3491;
        }else{
            latitude = group.latitude;
            longtitude = group.longtitude;
        }


        var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10,
        center: new google.maps.LatLng(latitude, longtitude),
        mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        var infowindow = new google.maps.InfoWindow();

        var marker, i;

        for (i = 0; i < locations.length; i++) {  
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map
        });

        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
            infowindow.setContent(locations[i][0]);
            infowindow.open(map, marker);
            }
        })(marker, i));
        }
    });
</script>
@endsection
