<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.min.js"></script>
    <link rel="stylesheet" href="{{ url('/') }}/css/WVDE.css">
</head>

<style>
    #gps {
        font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
        border-collapse: collapse;
    }

    #gps td,
    #gps th {
        border: 1px solid #ddd;
        padding: 8px;
    }

    #gps td {
        font-size: 0.8rem;
        height: 10;
    }

    #gps tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    #gps tr:hover {
        background-color: #ddd;
    }

    #gps tr {
        
    }

    #gps th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #4CAF50;
        color: white;
    }

    input {
        border: none;
        background: transparent;
    }
</style>

@php
    date_default_timezone_set("America/New_York");

@endphp

<h2>
    <img style="width:200px;height:60px;" src="/img/duke-energy.png" alt="bacson">
    <div id="time" style="float:right;"></div><br>
    <strong style="float:right;">
        <a href="{{ url('/') }}"><center>Bac Son Tech</center></a>
        
    </strong>
</h2>

@php

function getaddress($lat, $lng)
{
    $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat) . ',' . trim($lng) . '&key=AIzaSyA5f_FotlG5BbDQF3-VTSARJ3ZwKbVWab8';
    $json = @file_get_contents($url);
    $data = json_decode($json);
    if(is_null($data))
        return 'Not found';
    $status = $data->status;
    if ($status == "OK") {
        return $data->results[0]->formatted_address;
    } else {
        return 'Not found';
    }
}
@endphp

<center><h1><br>History</h1></center>
<table id="gps" width=100%>
    <thead>
        <tr>
            <th style="text-align: center;" width=90px>UnitID</th>
            <th style="text-align: center;" width=100px>Devices</th>
            <th style="text-align: center;" width=140px>Start Time</th>
            <th style="text-align: center;" width=140px>End Time</th>
            <th style="text-align: center;" >Last Address</th>
        </tr>
    </thead>

    <tbody id="myBody">
        @foreach($histories as $history)
        @php
        $address = getaddress($history->latitude, $history->longtitude);
        @endphp
        <tr>
            <td> {{$history->deviceID}} </td>
            <td> {{$history->toolWatch}} </td>
            <td> {{date('H:i:s m/d', $history->sTime)}}</td>
            <td> {{date('H:i:s m/d', $history->eTime)}}</td>
            <td> <a href="https://www.google.com/maps/search/?api=1&query={{$address}}">{{$address}}</a> </td>
        </tr>
        @endforeach
    </tbody>
</table>