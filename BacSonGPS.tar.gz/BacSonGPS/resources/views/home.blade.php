@extends('layouts.app')

@section('content')
<form method="POST" action="{{action('DeviceController@update')}}">
    @method('PATCH')
    @csrf
    <center>
    <h2><br>Search By Name</h2>
    <input id="myInput" style="border: 1px solid #000" type="text" placeholder="Search...">
    <br><br>
    <table class="tableDevice" id="gps" style="width=100%">
        <thead>
            <tr>
                <th style="text-align: center;" width=80px>UnitID</th>
                <th style="text-align: center;" width=40px>Name</th>
                <th style="text-align: center;" width=40px>Tool Watch</th>
                <th style="text-align: center;" width=15px>Power</th>
                <th style="text-align: center;" width=15px>Op Center</th>
                <th style="text-align: center;" width=180x>Last Report</th>
                <th style="text-align: center;" width=60px>Alert</th>
                <th style="text-align: center;" width=60px>History</th>
                <th style="text-align: center;" width=200px>Coordinate</th>
                <th style="text-align: center;" width=20%>Address</th>
                <th style="text-align: center;" width=20%>Note</th>
            </tr>
        </thead>

        <tbody id="myBody">
            @foreach($devices as $device)
            <tr>
                <td> {{$device->unitID}} </td>
                <td> {{$device->serial}} </td>
                <td> {{$device->toolWatch}} </td>
                <td> {{$device->powerStatus == 0 ? "DC" : "AC"}} </td>
                <td> {{$device->assignee}} </td>
                <td> {{date('H:i:s m/d/y', $device->lastReport)}} </td>
                <td>
                    <input type='hidden' value='0' name='alerts[{{$device->unitID}}]'>
                    <label class="switch">
                        <input class="form-check-input" type='checkbox' name="alerts[{{$device->unitID}}]" value="1" <?php echo $device->isAlert == '1' ? ' checked' : ''; ?> />
                        <span class="slider round"></span>
                    </label>
                </td>
                <td>
                    <div>
                        <a href="{{ action('DeviceController@show', ['unitID' => $device->unitID]) }}">
                            <button type="button" class="btn btn-primary btn-sm" name="viewDevice" title="View Device History"><i class="fa fa-eye"></i>
                            </button>
                        </a>
                    </div>
                </td>
                <td>
                    @if( $device->latitude == 0.000001 || $device->longtitude == 0.000001)
                        <p>Approx location by mobile signal</p>
                    
                    @else
                        <a href="https://maps.google.com/?q={{$device->latitude}},{{$device->longtitude}}">
                            {{$device->latitude}} , {{$device->longtitude}}
                        </a>
                    @endif
                </td>
                <td> <a href="https://www.google.com/maps/search/?api=1&query={{$device->address}}">{{$device->address}}</a> </td>
                <td> {{$device->note}} </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    </center>
</form>

<script type="text/javascript">
    $(document).ready(function() {
        console.log('eh');
        $("#myInput").on("keyup", function(e) {
            if (e.keyCode == 27) { //if hit ESC, clear all the text in text box
                $(this).val('');
            }
            var value = $(this).val().toLowerCase();
            $("#myBody tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        
    });
</script>
@endsection
