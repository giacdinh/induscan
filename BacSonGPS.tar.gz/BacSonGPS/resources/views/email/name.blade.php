<html>

<body>
    <!-- <p style="color:#3498DB;font-size:18px;">Device: ' . $uid . '</p>
    <p style="color:#3498DB;font-size:18px;">Firmware Version: ' . $fwv . '</p>
    <p style="color:#3498DB;font-size:18px;">Location: <a href="https://www.google.com/maps/search/?api=1&query=' . $address . '" style="color:#3498DB;font-size:18px;">' . $address . '</a></p>
    <p style="color:#3498DB;font-size:18px;">Coordinate: <a href="https://www.google.com/maps/search/?api=1&query=' . $latitude . ',' . $longtitude . '" style="color:#3498DB;font-size:18px;">' . $latitude . ', ' . $longtitude . '</a></p>
    <p style="color:#3498DB;font-size:18px;">Last report: ' . date('H:i:s m/d/Y', $now) . '</p>
    <p style="color:#3498DB;font-size:18px;">Temperature: ' . $temperature . ' &#176;F</p> -->
    <h1 style="color:#C70039;">From: Bac Son Tech LLC</h1>
</body>

</html>