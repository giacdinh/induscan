@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Service Verification</div>

                @if (session('status'))
                <div class="alert alert-success" role="alert">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    {{ session('status') }}
                </div>
                @elseif(session('failed'))
                <div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    {{ session('failed') }}
                </div>
                @endif

                <div class="card-body">
                    <form method="POST" action="{{ action('TicketController@store', ['groupId' => $group->groupId]) }}">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">Op Center:</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" value="{{$group->name}}" readonly>
                                <input type="hidden" name="groupId" value="{{$group->groupId}}">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="company" class="col-md-4 col-form-label text-md-right" title="You can also manually enter the device name">
                                <select class="form-control" id="devices">
                                    <option value="">- Select Device Name -</option>
                                    @foreach($devices as $device)
                                        <option value="{{$device->serial}}">{{$device->serial}}</option>
                                    @endforeach
                                </select>
                            </label>
                            
                            <div class="col-md-6">
                                <input type="text" class="form-control" id="deviceName" name="serial" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="company" class="col-md-4 col-form-label text-md-right">Truck #:</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="truckNumber">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="company" class="col-md-4 col-form-label text-md-right">Meter #:</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="meterNumber">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="company" class="col-md-4 col-form-label text-md-right">Address:</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="address">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="company" class="col-md-4 col-form-label text-md-right">Action:</label>

                            <div class="col-md-6">
                                <select class="form-control" name="action">
                                    <option value="Transfer">Transfer</option>
                                    <option value="Install">Install</option>
                                    <option value="Remove">Remove</option>
                                    <option value="Base Check-in">Base Check-in</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                            </div>
                        </div> 
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $( "#devices" ).change(function() {
            $("#deviceName").val($(this).val());
        }); 
    });
</script>
@endsection