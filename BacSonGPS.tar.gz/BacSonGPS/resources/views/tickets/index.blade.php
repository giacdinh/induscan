@extends('layouts.app')

@section('content')
    <h2 class="text-center">Ticket List</h2>
    <br><br>
    <table class="table table-sm">
        <thead>
            <tr>
                <th>Name</th>
                <th>Toolwatch</th>
                <th>Truck #</th>
                <th>Meter #</th>
                <th>Coordinate</th>
                <th>Address</th>
                <th>Actual Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($tickets as $ticket)
                <tr class="text-center">
                    <td>{{$ticket->serial}}</td>
                    <td>{{$ticket->toolWatch}}</td>
                    <td>{{$ticket->truckNumber}}</td>
                    <td>{{$ticket->meterNumber}}</td>
                    <td>{{$ticket->latitude}} ,{{$ticket->longtitude}}</td>
                    <td>{{$ticket->address}}</td>
                    <td>{{$ticket->actualAddress}}</td>
                    <td>{{$ticket->action}}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection