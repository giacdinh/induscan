@extends('layouts.app')

@section('content')
<center><h2>Assign Device</h2></center>
<br>
<form class="container" method="POST" action="{{action('DeviceController@saveAssignedDevices')}}">
    @csrf
    <div class="row">
        <div class="col-md-6">
            <center><h6>Unassigned Devices</h6></center>
            <select class="form-control" name="deviceId" size="{{ count($devices) }}">
                @foreach($devices as $device)
                    <option value="{{$device->id}}">{{$device->unitID}}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-6">
            <center><h6>Operation Centers</h6></center>
            <select class="form-control" name="groupId" size="{{ count($groups) }}">
                @foreach($groups as $group)
                    <option value="{{$group->groupId}}">{{$group->name}}</option>
                @endforeach
            </select>
        </div>
    </div>
    <br>
    <center>
        <br><button type="submit" class="btn btn-primary">Assign Device</button>
    </center>
</form>
@endsection