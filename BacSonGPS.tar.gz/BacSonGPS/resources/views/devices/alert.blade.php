@extends('layouts.app')

@section('content')
<center><h2>Alert Settings</h2></center>
<br>

    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align:center;"> <input type="checkbox"/> </td>
                    <td style="text-align:center;"> Service set </td>
                    <td style="text-align:center;"> Set at service point or first from DC to AC </td>
                </tr>
                <tr>
                    <td style="text-align:center;"> <input type="checkbox"> </td>
                    <td style="text-align:center;"> Long service </td>
                    <td style="text-align:center;"> At service site more than 14 days. </td>
                </tr>
                <tr>
                    <td style="text-align:center;"> <input type="checkbox"> </td>
                    <td style="text-align:center;"> Service unset </td>
                    <td style="text-align:center;"> Unset at service point or first AC to DC </td>
                </tr>
                <tr>
                    <td style="text-align:center;"> <input type="checkbox"> </td>
                    <td style="text-align:center;"> Return to base </td>
                    <td style="text-align:center;"> On DC at correct OpCenter </td>
                </tr>
                <tr>
                    <td style="text-align:center;"> <input type="checkbox"> </td>
                    <td style="text-align:center;"> Return to wrong base </td>
                    <td style="text-align:center;"> Back at wrong OpCenter </td>
                </tr>
                <tr>
                    <td style="text-align:center;"> <input type="checkbox"> </td>
                    <td style="text-align:center;"> Not return base </td>
                    <td style="text-align:center;"> Unset service for 3+ days and not return at any OpCenter </td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>
    <center>
        <br><button type="button" class="btn btn-primary">Save</button>
    </center>

@endsection