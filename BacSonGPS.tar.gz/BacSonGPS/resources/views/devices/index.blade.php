@extends('layouts.app')

@section('content')

@php
date_default_timezone_set("America/New_York");
function getaddress($lat, $lng)
{
    $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat) . ',' . trim($lng) . '&key=AIzaSyA5f_FotlG5BbDQF3-VTSARJ3ZwKbVWab8';
    $json = @file_get_contents($url);
    $data = json_decode($json);
    if(is_null($data))
        return 'Not found';
    $status = $data->status;
    if ($status == "OK") {
        return $data->results[0]->formatted_address;
    } else {
        return 'Not found';
    }
}
@endphp



<form method="POST" action="{{action('DeviceController@update')}}">
    @method('PATCH')
    @csrf
    <center>
    <h2><br>Search By Name</h2>
    <input id="myInput" style="border: 1px solid #000" type="text" placeholder="Search...">
    <br><br>
    <table class="tableDevice" id="gps" style="width=100%">
        <thead>
            <tr>
                <th style="text-align: center;" width=80px>UnitID</th>
                <th style="text-align: center;" width=40px>Name</th>
                <th style="text-align: center;" width=40px>Tool Watch</th>
                <th style="text-align: center;" width=15px>Manager</th>
                <th style="text-align: center;" width=15px>Op Center</th>
                <th style="text-align: center;" width=180x>Last Report</th>
                <th style="text-align: center;" width=60px>Alert</th>
                <th style="text-align: center;" width=60px>History</th>
                <th style="text-align: center;" width=200px>Coordinate</th>
                <th style="text-align: center;" width=20%>Address</th>
                <th style="text-align: center;" width=20%>Comment</th>
            </tr>
        </thead>

        <tbody id="myBody">
            @foreach($devices as $device)
            @php
            $address = getaddress($device->latitude, $device->longtitude);
            @endphp
            <tr>
                <td> {{$device->unitID}} </td>
                <td> {{$device->serial}} </td>
                <td> {{$device->toolWatch}} </td>
                <td> {{$device->manager}} </td>
                <td> {{$device->assignee}} </td>
                <td> {{date('H:i:s m/d/y', $device->lastReport)}} </td>
                <td>
                    <input type='hidden' value='0' name='actives[{{$device->unitID}}]'>
                    <label class="switch">
                        <input class="form-check-input" type='checkbox' name="actives[{{$device->unitID}}]" value="1" <?php echo $device->isActive == '1' ? ' checked' : ''; ?> />
                        <span class="slider round"></span>
                    </label>
                </td>
                <td>
                    <input type='hidden' value='0' name='alerts[{{$device->unitID}}]'>
                    <label class="switch">
                        <input class="form-check-input" type='checkbox' name="alerts[{{$device->unitID}}]" value="1" <?php echo $device->isAlert == '1' ? ' checked' : ''; ?> />
                        <span class="slider round"></span>
                    </label>
                </td>
                <td>
                    <div>
                        <a href="{{ action('DeviceController@show', ['unitID' => $device->unitID]) }}">
                            <button type="button" class="btn btn-primary btn-sm" name="viewDevice" title="View Device History"><i class="fa fa-eye"></i>
                            </button>
                        </a>
                    </div>
                </td>
                <td>
                    <a href="https://maps.google.com/?q={{$device->latitude}},{{$device->longtitude}}">
                        {{$device->latitude}} , {{$device->longtitude}}
                    </a>
                </td>
                <td> <a href="https://www.google.com/maps/search/?api=1&query={{$address}}">{{$address}}</a> </td>
                <td></td>
            </tr>
            @endforeach
        </tbody>
    </table>
    </center>
</form>
<h6>
    <strong style="float:left;">
        <a href="{{ url('/home') }}"><center>Back to Home</center></a>
    </strong>
</h6>

<script type="text/javascript">
    $(document).ready(function() {
        console.log('eh');
        $("#myInput").on("keyup", function(e) {
            if (e.keyCode == 27) { //if hit ESC, clear all the text in text box
                $(this).val('');
            }
            var value = $(this).val().toLowerCase();
            $("#myBody tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        
    });
</script>
@endsection
