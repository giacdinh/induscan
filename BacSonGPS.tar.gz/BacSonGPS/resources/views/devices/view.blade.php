@extends('layouts.app')

@section('content')

@if ($histories->isEmpty())
    <br>
    <center><p>Current Device's History Is Empty</p></center>
@else


<center><h1><br>History of {{$histories->first()->toolWatch}} (UnitID: {{$histories->first()->deviceID}})</h1></center>
<table id="gps" width=100%>
    <thead>
        <tr>
            <th style="text-align: center;" width=140px>Start Time</th>
            <th style="text-align: center;" width=140px>End Time</th>
            <th style="text-align: center;" width=140px>Duration</th>
            <th style="text-align: center;" width=140px>Assignee</th>
            <th style="text-align: center;" width=140px>Firmware</th>
            <th style="text-align: center;" width=140px>Power</th>
            <th style="text-align: center;" >Last Location</th>
        </tr>
    </thead>

    <tbody id="myBody">
        @php
        $currentHistory = $currentHistory->first();
        $timeDiff = floor(($currentHistory->lastReport - $currentHistory->startTime) / (60 * 60 * 24));
        @endphp
        <tr>
            <td> {{date('H:i:s m/d', $currentHistory->startTime)}}</td>
            <td> {{date('H:i:s m/d', $currentHistory->lastReport)}}</td>
            <td> {{$timeDiff}} day(s)</td>
            <td> {{$currentHistory->operator}}</td>
            <td> {{$currentHistory->firmwareVersion}} </td>
            <td> {{$currentHistory->powerStatus == 0 ? "DC" : "AC"}} </td>
            <td> <a href="https://www.google.com/maps/search/?api=1&query={{$currentHistory->address}}">{{$currentHistory->address}}</a> </td>
        </tr>
        @foreach($histories as $history)
        @php
        $timeDiff = floor(($history->eTime - $history->sTime) / (60 * 60 * 24));
        @endphp
        <tr>
            <td> {{date('H:i:s m/d', $history->sTime)}}</td>
            <td> {{date('H:i:s m/d', $history->eTime)}}</td>
            <td> {{$timeDiff}} day(s)</td>
            <td> {{$history->operator}}</td>
            <td> {{$history->firmwareVersion}}</td>
            <td> {{$history->powerStatus == 0 ? "DC" : "AC"}} </td>
            <td> <a href="https://www.google.com/maps/search/?api=1&query={{$history->address}}">{{$history->address}}</a> </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endif

<script type="text/javascript">
    $(document).ready(function() {
        $("#myInput").on("keyup", function(e) {
            if (e.keyCode == 27) { //if hit ESC, clear all the text in text box
                $(this).val('');
            }
            var value = $(this).val().toLowerCase();
            $("#myBody tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        
    });

    function showTime() {
    var date = new Date();
    var utc = new Date(Date.UTC(
          date.getFullYear(),
          date.getMonth(),
          date.getDate(),
          date.getHours() + 5,
          date.getMinutes(),
          date.getSeconds()
        ));
    

    document.getElementById('time').innerHTML = utc.toLocaleTimeString();
    }
    setInterval(showTime, 1000);
  

</script>
@endsection