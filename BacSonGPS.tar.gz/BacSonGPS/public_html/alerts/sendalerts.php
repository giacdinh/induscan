<?php
//setup connection
$servername = "sql182.main-hosting.eu";
$database = "u426042465_prod";
$username = "u426042465_dlj";
$password = "An940822?";
$deviceTable = "devices";
$groupToDevicesTable = "groupToDevices";
$historyTable = "histories";
$alertTable = "alerts";
$groupTable = "groups";

$conn = new mysqli($servername, $username, $password, $database);
if (!$conn) {
    $logFailed = "Cannot established connection on " . date('H:i:s m/d/Y', $now) . ".\n";
    file_put_contents("Log/FailedRequestLog.txt", $logFailed, FILE_APPEND | LOCK_EX); //Log the failed request
    die("Connection failed: " . mysqli_connect_error());
}

$needAlertDeviceIds = array();

$readFile = fopen("DeviceId.txt", "r");
if ($readFile) {
    while (($line = fgets($readFile)) !== false) {
        array_push($needAlertDeviceIds, preg_replace('/\s+/', '', $line));
    }
    fclose($readFile);
} else {
    $logFailed = "Cannot read alert files on " . date('H:i:s m/d/Y', $now) . ".\n";
    file_put_contents("Log/FailedRequestLog.txt", $logFailed, FILE_APPEND | LOCK_EX); //Log the failed request
}

$needAlertDeviceIds = array_unique($needAlertDeviceIds);

foreach($needAlertDeviceIds as $needAlertDeviceId){
    $query = "SELECT * FROM `{$deviceTable}` WHERE unitID = '$needAlertDeviceId'";
    $deviceQuery = $conn->query("$query");
    if (mysqli_num_rows($deviceQuery) != 0){
        $alerts = array();
        $device = $deviceQuery->fetch_assoc();
        array_push($alerts, ProducePowerChangeAlerts($device));
        array_push($alerts, ProduceAtBaseAlerts($device));
        $deviceId = $device['unitID'];
        $note = implode(' | ', $alerts);
        $updateNote = $conn->query("UPDATE `{$deviceTable}` SET note='$note' WHERE unitID = '$deviceId'");
        if (!$updateNote) {
            $logFailed = "Cannot update note alert for " . $deviceId . " on " . date('H:i:s m/d/Y', $now) . ".\n";
            file_put_contents("Log/FailedRequestLog.txt", $logFailed, FILE_APPEND | LOCK_EX); //Log the failed request
        }
    }
}

file_put_contents("DeviceId.txt", "");

function ProduceAtBaseAlerts($device){
    global $conn, $groupTable;
    $deviceId = $device['unitID'];
    $deviceLatitude = $device['latitude'];
    $deviceLongtitude = $device['longtitude'];
    $groupsInfoQuery = $conn->query("SELECT * FROM `{$groupTable}` WHERE latitude IS NOT NULL AND longtitude IS NOT NULL");
    while ($group = $groupsInfoQuery->fetch_assoc()) {
        $groupLatitude = $group['latitude'];
        $groupLongtitude = $group['longtitude'];
        $groupName = $group['name'];
        if((abs($groupLatitude - $deviceLatitude) < 0.002 && abs($groupLongtitude - $deviceLongtitude) < 0.002)){
            return "At base " . $groupName;
        }
    }
    return null;
}

function ProducePowerChangeAlerts($device){
    global $conn, $historyTable;
    $deviceId = $device['unitID'];
    $deviceCurrentPower = $device['powerStatus'] == 0 ? "DC" : "AC";
    $deviceOldPowerQuery = $conn->query("SELECT powerStatus FROM `{$historyTable}` where deviceID = '$deviceId' ORDER BY id DESC LIMIT 1");
    $deviceOldPower = ($deviceOldPowerQuery->fetch_assoc())['powerStatus'] == 0 ? "DC" : "AC";
    if ($deviceCurrentPower != $deviceOldPower){
        return "Power changed from  " . $deviceOldPower. ' to ' . $deviceCurrentPower;
    }
    return null;
}
