<?php
require __DIR__ . '/sendEmail.php';
//setup connection
$servername = "sql182.main-hosting.eu";
date_default_timezone_set("America/New_York");
//get data from the url parameters
$inc = array();
$inc = array_merge($inc, $_POST);
$inc = array_merge($inc, $_GET);
//get long,lat
$coord = $inc['coord'];
$coord = str_replace(' ', '', $coord);
$temp = explode(",", $coord);
$latitude = $temp[0];
$longtitude = $temp[1];
//get other data
$uid = $inc['uid'];
$fwv = $inc['fwv'];
$pwr = $inc['pwr'];
$t = $inc['t'];
$temperature = convertToFahrenheit(explode("'C", $inc['temp'])[0]);

$now = time();
$status = '';
$lastReport = '';
$tableCode = $uid[0] . $uid[1];
$tableCode = strtolower($tableCode);

switch ($tableCode) {
    case "de":
        $database = "u426042465_prod";
        $username = "u426042465_dlj";
        $password = "An940822?";
        $deviceTable = "devices";
        $groupToDevicesTable = "groupToDevices";
        $historyTable = "histories";
        $alertTable = "alerts";
        break;
    default:
        exit('Table name not available');
}

$logReceived = "Device ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . " was posted on " . date('H:i:s m/d/Y', $now) . "\n";
file_put_contents("Log/ReceivedRequestLog.txt", $logReceived, FILE_APPEND | LOCK_EX); //Log the posted request
$conn = new mysqli($servername, $username, $password, $database);

if (!$conn) {
    $logFailed = "Device ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . " was posted on " . date('H:i:s m/d/Y', $now) . " but cannot connect to the database.\n";
    file_put_contents("Log/FailedRequestLog.txt", $logFailed, FILE_APPEND | LOCK_EX); //Log the failed request
    die("Connection failed: " . mysqli_connect_error());
}

$currentRecord = $conn->query("SELECT * FROM `{$deviceTable}` WHERE unitID = '$uid'");
$newAddress = getaddress($latitude, $longtitude);

if (mysqli_num_rows($currentRecord) == 0) { //not exist, create new record
    $lastReport = date('H:i:s m/d/Y', $now);
    //echo "Not exist, attempt to insert new record";
    
    $sql = "INSERT INTO `{$deviceTable}` (unitID, firmwareVersion, latitude, longtitude, temperature, powerStatus, startTime, lastReport, address) VALUES ('$uid', '$fwv', '$latitude', '$longtitude', '$temperature', '$pwr', '$now', '$now', '$newAddress');";
    if (mysqli_query($conn, $sql)) {
        //echo "Records inserted successfully.";
        $deviceId = $conn->insert_id;
        $sql = "INSERT INTO `{$groupToDevicesTable}` (groupId, deviceId) VALUES (1, '$deviceId');";
        if(mysqli_query($conn, $sql)){
            http_response_code(206);
        }
        http_response_code(500);
    } else {
        //echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
        http_response_code(500);
    }
} else { //existed, update record
    //echo "exist";
    $row = $currentRecord->fetch_assoc();
    $lastReport = $row['lastReport'];
    $currentLat = $row['latitude'];
    $currentLong = $row['longtitude'];
    $currentPowerStatus = $row['powerStatus'];
    $operator = $row['operator'];
    $currentAddress = $row['address'];

    if ($currentPowerStatus != $pwr || 
        ((abs($currentLat - $latitude) > 0.002 || abs($currentLong - $longtitude) > 0.002) && $currentLat != 0.000001 && $currentLong != 0.000001)) { //add record to history if the GPS lat or Long change more then 0.002
        
        file_put_contents("alerts/DeviceId.txt", $uid . "\n", FILE_APPEND | LOCK_EX);
        $sql = "INSERT INTO `{$historyTable}` (deviceID, firmwareVersion, powerStatus, latitude, longtitude, sTime, eTime, address, operator) VALUES ('$uid', '$fwv', '$currentPowerStatus', '$currentLat', '$currentLong', '$lastReport', '$now', '$currentAddress', '$operator');";
        if (mysqli_query($conn, $sql)) {
            //echo "Records inserted successfully.";
            http_response_code(206);
        } else {
            //echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
            http_response_code(500);
        }

        $queryStartTime = $conn->query("UPDATE `{$deviceTable}` SET startTime='$now' WHERE unitID = '$uid'");

        if ($queryStartTime) {
            //echo 'Update uid: ' . $uid . ' successful';
            http_response_code(206);
        } else {
            //echo 'Update uid: ' . $uid . ' not successful';
            http_response_code(500);
        }
    }

    //update the record in device table
    $query = $conn->query("UPDATE `{$deviceTable}` SET firmwareVersion='$fwv', latitude='$latitude', longtitude='$longtitude', temperature='$temperature', powerStatus='$pwr', lastReport='$now', address='$newAddress' WHERE unitID = '$uid'");

    if ($query) {
        //echo 'Update uid: ' . $uid . ' successful';
        http_response_code(206);
    } else {
        //echo 'Update uid: ' . $uid . ' not successful';
        http_response_code(500);
    }
}

$conn->close();

$logSuccess = "Device ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . "\tTemp: " . $inc['temp'] . " was posted and stored successfuly on " . date('H:i:s m/d/Y', $now) . "\n";
file_put_contents("Log/SuccessRequestLog.txt", $logSuccess, FILE_APPEND | LOCK_EX); //Log the success request

sendEmail($newAddress, $uid, $fwv, $temperature, $latitude, $longtitude, $now, $pwr, $t);
// //Send email
// ini_set('display_errors', 1);
// error_reporting(E_ALL);
// $from = "bacsonteam@bacson.tech";
// $to = "ghecu@hotmail.com";
// $subject = "TrackingDE";
// $address = $newAddress;

// // To send HTML mail, the Content-type header must be set
// $headers  = 'MIME-Version: 1.0' . "\r\n";
// $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// // Create email headers
// $headers .= 'From: ' . $from . "\r\n" .
//     'Reply-To: ' . $from . "\r\n" .
//     'X-Mailer: PHP/' . phpversion();

// $message = '<html><body>';
// $message .= '<p style="color:#3498DB;font-size:18px;">Device: ' . $uid . '</p>';
// $message .= '<p style="color:#3498DB;font-size:18px;">Firmware Version: ' . $fwv . '</p>';
// $message .= '<p style="color:#3498DB;font-size:18px;">Location: <a href="https://www.google.com/maps/search/?api=1&query=' . $address . '" style="color:#3498DB;font-size:18px;">' . $address . '</a></p>';
// $message .= '<p style="color:#3498DB;font-size:18px;">Coordinate: <a href="https://www.google.com/maps/search/?api=1&query=' . $latitude . ',' . $longtitude . '" style="color:#3498DB;font-size:18px;">' . $latitude . ', ' . $longtitude . '</a></p>';
// $message .= '<p style="color:#3498DB;font-size:18px;">Last report: ' . date('H:i:s m/d/Y', $now) . '</p>';
// $message .= '<p style="color:#3498DB;font-size:18px;">Temperature: ' . $temperature . ' &#176;F</p>';
// $message .= '<h1 style="color:#C70039;">From: Bac Son Tech LLC</h1>';
// $message .= '</body></html>';

// if (mail($to, $subject, $message, $headers)) {
//     mail("cusinbs@gmail.com", $subject, $message, $headers);
//     $logSendEmail = date('H:i:s m/d/Y', $now) . "\tDevice ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . "\tTemp: " . $inc['temp'] . "\tEmail Status: Sent\n";
//     //echo 'Your mail has been sent successfully.';
//     http_response_code(200);
// } else {
//     $logSendEmail = date('H:i:s m/d/Y', $now) . "\tDevice ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . "\tTemp: " . $inc['temp'] . "\tEmail Status: Not Sent\n";
//     //echo 'Unable to send email. Please try again.';
//     http_response_code(503);
// }

// $logSuccessEmail = "\tDevice ID: " . $inc['uid']. "\tCoord: " . $inc['coord'] . "\tTemp: " . $inc['temp'] . " was posted and stored and emailed successfuly on " . date('H:i:s m/d/Y', $now) . "\n";
// file_put_contents("Log/SuccessEmailRequestLog.txt", $logSuccessEmail, FILE_APPEND | LOCK_EX); //Log the success request

function getaddress($lat, $lng)
{
    global $currentRecord;
    $useSimId = '';
    if(($lat == "0.000001" || $lng == "0.000001") && mysqli_num_rows($currentRecord) != 0){
        $useSimId = 'Sim Location: ';
        $row = $currentRecord->fetch_assoc();
        $simID = $row['simID'];
        $url = 'https://dashboard.hologram.io/api/1/devices/' . trim($simID) . '?apikey=4w8iOiHptYrLf5CL05fBFRTEOXvGCZ';
        $json = @file_get_contents($url);
        $response = json_decode($json);
        $status = $response->success;
        if ($status == "true") {
            $currentLocation = $response->data->lastsession;
            $lat = $currentLocation->latitude;
            $lng = $currentLocation->longitude;
        } else {
            return 'Not Available';
        }
    }

    $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat) . ',' . trim($lng) . '&key=AIzaSyA5f_FotlG5BbDQF3-VTSARJ3ZwKbVWab8';
    $json = @file_get_contents($url);
    $data = json_decode($json);
    $status = $data->status;
    if ($status == "OK") {
        return $useSimId . $data->results[0]->formatted_address;
    } else {
        return 'Not Available';
    }
}

function convertToFahrenheit($temperature)
{
    $temp = (float) $temperature;
    return $temp * 1.8 + 32;
}