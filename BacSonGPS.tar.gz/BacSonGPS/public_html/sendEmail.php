<?php
//Send email
function sendEmail($newAddress, $uid, $fwv, $temperature, $latitude, $longtitude, $now, $pwr, $t){
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
    $from = "bacsonteam@bacson.tech";
    $to = "ghecu@hotmail.com";
    $subject = "dlj2020.tech";
    $address = $newAddress;

    // To send HTML mail, the Content-type header must be set
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    // Create email headers
    $headers .= 'From: ' . $from . "\r\n" .
        'Reply-To: ' . $from . "\r\n" .
        'X-Mailer: PHP/' . phpversion();

    $message = '<html><body>';
    $message .= '<p style="color:#3498DB;font-size:18px;">Dev: ' . $uid . '</p>';
    $message .= '<p style="color:#3498DB;font-size:18px;">Fw: ' . $fwv . '</p>';
    if($pwr == 0){
        $message .= '<p style="color:#3498DB;font-size:18px;">Pwr: DC </p>';
    }else{
        $message .= '<p style="color:#3498DB;font-size:18px;">Pwr: AC </p>';
    }
    $message .= '<p style="color:#3498DB;font-size:18px;">Temp: ' . $temperature . '</p>';
    $message .= '<p style="color:#3498DB;font-size:18px;">Cord: <a href="https://www.google.com/maps/search/?api=1&query=' . $latitude . ',' . $longtitude . '" style="color:#3498DB;font-size:18px;">' . $latitude . ', ' . $longtitude . '</a></p>';
    $message .= '<p style="color:#3498DB;font-size:18px;">At: <a href="https://www.google.com/maps/search/?api=1&query=' . $address . '" style="color:#3498DB;font-size:18px;">' . $address . '</a></p>';
    $message .= '<p style="color:#3498DB;font-size:18px;">T: ' . $t . '</p>';
    $message .= '<h1 style="color:#C70039;">From: Bac Son Tech LLC</h1>';
    $message .= '</body></html>';

    if (mail($to, $subject, $message, $headers)) {
        //echo 'Your mail has been sent successfully.';
        http_response_code(200);
    } else {
        //echo 'Unable to send email. Please try again.';
        http_response_code(503);
    }

    $logSuccessEmail = "\tDevice ID: " . $uid. "\tCoord: " . $latitude . ',' . $longtitude . "\tTemp: " . $temperature . " was posted and stored and emailed successfuly on " . date('H:i:s m/d/Y', $now) . "\n";
    file_put_contents("Log/SuccessEmailRequestLog.txt", $logSuccessEmail, FILE_APPEND | LOCK_EX); //Log the success request
}
