<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('home', 'HomeController@index')->name('home');
Route::get('/map-view', 'HomeController@mapView');
//Device
Route::get('/device', 'DeviceController@index')->name('device'); //Get tables of Device
Route::get('/alert/settings', 'DeviceController@alertSettings'); 
Route::get('/device/assign', 'DeviceController@assignDevices'); //Assign devices
Route::post('/device/assign', 'DeviceController@saveAssignedDevices'); //Save assigned devices
Route::get('/device/{device}', 'DeviceController@show'); //Show devices
Route::patch('/device', 'DeviceController@update')->name('device'); //Update devices
Route::get('/history', 'HistoryController@index')->name('device');
//Ticket
Route::get('/ticket/groupId/{group}', 'TicketController@index'); //Get tables of Tickets
Route::get('/ticket/groupId/{group}/create', 'TicketController@create'); //Create Ticket
Route::post('/ticket/groupId/{group}', 'TicketController@store'); //Create Ticket