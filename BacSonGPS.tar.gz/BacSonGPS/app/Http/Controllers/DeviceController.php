<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Providers\DeviceProvider;
use App\Providers\GroupProvider;

class DeviceController extends Controller
{
    protected $db_device;
    protected $db_group;

    public function __construct(DeviceProvider $db_device, GroupProvider $db_group)
    {
        $this->db_device = $db_device;
        $this->db_group = $db_group;
    }

    public function index()
    {
        $devices = $this->db_device->getDevices(Auth::user()->id);
        return view('devices.index',compact('devices'));
    }

    public function assignDevices()
    {
        $devices = $this->db_device->getUnassignedDevices();
        $groups = $this->db_group->getAllGroups();
        return view('devices.assign',compact('devices', 'groups'));
    }

    public function alertSettings()
    {
        return view('devices.alert');
    }

    public function saveAssignedDevices(Request $request)
    {
        if($request->deviceId == null || $request->groupId == null){
            return redirect()->back();
        }
        $this->db_group->assignDeviceToGroup($request->deviceId, $request->groupId);
        return redirect()->back();
    }

    public function show(Request $request, $unitID)
    {
        $histories = $this->db_device->getDeviceHistory($unitID);
        $currentHistory = $this->db_device->getDevice($unitID);
        return view('devices.view', compact('histories', 'currentHistory'));
    }

    public function update(Request $request)
    {
        $unitManagers = $request->unitManagers;
        $unitAssignees = $request->unitAssignees;
        $alerts = $request->alerts;
        
        $addresses = $request->unitAddress;

        foreach($unitNames as $unitID => $unitName) {
            if(!is_null($unitName)) {
                $this->db_device->updateDeviceName($unitID , $unitName);
            }
        }
        foreach($unitOperators as $unitID => $unitOperator) {
            if(!is_null($unitOperator)) {
                $this->db_device->updateDeviceOperator($unitID , $unitOperator);
            }
        }
        // foreach($actives as $unitID => $active) {
        //     $this->db_device->updateActive($unitID, $active);
        // }
        foreach($alerts as $unitID => $alert) {
            $this->db_device->updateAlert($unitID, $alert);
        }
        foreach($addresses as $unitID => $unitAddress) {
            if(!is_null($unitAddress)) {
                $this->db_device->updateDeviceAddress($unitID , $unitAddress);
            }
        }
        return redirect()->back();
    }
}
