<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Providers\DeviceProvider;
use App\Providers\GroupProvider;
use Auth;

class HomeController extends Controller
{
    protected $db_device;
    protected $db_group;
    
    public function __construct(DeviceProvider $db_device, GroupProvider $db_group)
    {
        $this->middleware('auth');
        $this->db_device = $db_device;
        $this->db_group = $db_group;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $devices = $this->db_device->getDevices(Auth::user()->id);
        return view('home',compact('devices'));

        // $currentUser = Auth::user();
        // $devices = $this->db_device->getDevices($currentUser->id);
        // $group = $this->db_group->getGroupByUserId($currentUser->id)->first();

        // return view('home',compact('devices', 'currentUser', 'group'));
    }

    public function mapView()
    {
        $currentUser = Auth::user();
        $devices = $this->db_device->getDevices($currentUser->id);
        $group = $this->db_group->getGroupByUserId($currentUser->id)->first();

        return view('map',compact('devices', 'currentUser', 'group'));
    }

    public function mail()
    {
        $name = 'Anh';
        Mail::to('cusinbs@gmail.com')->send(new SendMailable($name));

        return 'Email was sent';
    }
}
