<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validator;
use App\Ticket;
use App\Providers\TicketProvider;
use App\Providers\GroupProvider;
use App\Providers\DeviceProvider;

class TicketController extends Controller
{
    protected $db_ticket;
    protected $db_group;

    public function __construct(TicketProvider $db_ticket, GroupProvider $db_group, DeviceProvider $db_device)
    {
        $this->db_ticket = $db_ticket;
        $this->db_group = $db_group;
        $this->db_device = $db_device;
    }

    public function index($groupId)
    {
        $tickets = $this->db_ticket->getAllTickets($groupId);
        return view('tickets.index', compact('tickets'));
    }

    public function create($groupId)
    {
        $group = $this->db_group->getGroupByGroupId($groupId);
        $devices = $this->db_device->getDevicesByGroupId($groupId);
        return view('tickets.create', compact('group', 'devices'));
    }

    public function store(Request $request, $groupId)
    {
        $rules = [
			'serial' => 'required',
			'groupId' => 'required'
		];
		$validator = Validator::make($request->all(),$rules);
		if ($validator->fails()) {
			return redirect()->back()->with('failed',"Invalid Input");
		}
		else{
            $data = $request->input();
			try{
				$ticket = new Ticket;
                $ticket->groupId = $data['groupId'];
                $ticket->serial = $data['serial'];
				$ticket->truckNumber = $data['truckNumber'];
				$ticket->meterNumber = $data['meterNumber'];
                $ticket->address = $data['address'];
                $ticket->action = $data['action'];
				$ticket->save();
				return redirect()->back()->with('status',"Insert successfully");
			}
			catch(Exception $e){
				return redirect()->back()->with('failed',"Operation failed");
			}
		}
    }
}
