<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Providers\HistoryProvider;

class HistoryController extends Controller
{

    protected $db_history;

    public function __construct(HistoryProvider $db_history)
    {
        $this->db_history = $db_history;
    }

    public function index()
    {
        $histories = $this->db_history->getHistory();
        return view('history.index', compact('histories'));
    }
}
