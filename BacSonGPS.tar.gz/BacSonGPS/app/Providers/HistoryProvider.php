<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;

class HistoryProvider
{
    public function getHistory()
    {
        return DB::table('de-histories')
            ->get();
    }
}
