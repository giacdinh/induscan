<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;

class TicketProvider
{
    public function getAllTickets($groupId)
    {
        return DB::table('tickets')
                ->leftJoin('devices','devices.serial', '=', 'tickets.serial')
                ->where('groupId', $groupId)
                ->select('tickets.*','devices.toolWatch','devices.latitude','devices.longtitude', 'devices.address as actualAddress')
                ->get();
    }
}