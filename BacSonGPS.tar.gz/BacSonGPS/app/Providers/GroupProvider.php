<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;

class GroupProvider
{
    public function getAllGroups() 
    {
        return DB::table('groups')
            ->where('groups.groupId', '<>', 1)
            ->get();
    }

    public function getGroupByUserId($userId)
    {
        return DB::table('groups')
            ->join('groupToUsers', 'groups.groupId', '=', 'groupToUsers.groupId')
            ->where('groupToUsers.userId', $userId)
            ->get();
    }

    public function assignDeviceToGroup($deviceId, $groupId)
    {
        if (DB::table('groupToDevices')->where('groupId', $groupId)->where('deviceId', $deviceId)->doesntExist()) {
            $isInserted = DB::table('groupToDevices')
                            ->insert([
                                'deviceId' => $deviceId,
                                'groupId' => $groupId
                            ]);
            if($isInserted){
                DB::table('groupToDevices')->where('groupId', 1)->where('deviceId', $deviceId)->delete();
            }
        }
        
    }

    public function isGroupOperator($userId)
    {
        return DB::table('groups')
            ->where('operatorId', $userId)
            ->exists();
    }

    public function getGroupByOperatorId($operatorId)
    {
        return DB::table('groups')
            ->where('operatorId', $operatorId)
            ->first();
    }

    public function getGroupByGroupId($groupId)
    {
        return DB::table('groups')
            ->where('groupId', $groupId)
            ->first();
    }
}
