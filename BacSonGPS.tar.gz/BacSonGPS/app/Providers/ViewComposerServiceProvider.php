<?php
namespace App\Providers;

use DB;
use Illuminate\Support\ServiceProvider;
use View;
use Auth;
use App\Providers\GroupProvider;

class ViewComposerServiceProvider extends ServiceProvider
{

    public function __construct()
    {
        $this->db_group = resolve(\App\Providers\GroupProvider::class);
    }

    public function boot()
    {
        View::composer('*', function($view){
            if(!Auth::guest()){
                $isOperator =  $this->db_group->isGroupOperator(Auth::user()->id);
                $groupId = 0;
                if($isOperator){
                    $groupId = ($this->db_group->getGroupByOperatorId(Auth::user()->id))->groupId;
                }
                //any code to set $val variable
                $view->with('groupId', $groupId);
            }
        });
    }
}