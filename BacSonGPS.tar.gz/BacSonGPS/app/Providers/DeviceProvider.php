<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;

class DeviceProvider
{
    public function getDevices($userID) 
    {
        return $temp = DB::table('devices')
            ->join('groupToDevices', 'devices.id', '=', 'groupToDevices.deviceId')
            ->join('groupToUsers', 'groupToDevices.groupId', '=', 'groupToUsers.groupId')
            ->where('groupToUsers.userId', $userID)
            ->orderBy('serial', 'asc')
            ->get();
    }

    public function getUnassignedDevices() 
    {
        return $temp = DB::table('devices')
            ->join('groupToDevices', 'devices.id', '=', 'groupToDevices.deviceId')
            ->where('groupToDevices.groupId', '=', '1')
            ->get();
    }

    public function getDevicesByGroupId($groupId) 
    {
        return $temp = DB::table('devices')
            ->join('groupToDevices', 'devices.id', '=', 'groupToDevices.deviceId')
            ->where('groupToDevices.groupId', '=', $groupId)
            ->orderBy('devices.serial', 'asc')
            ->get();
    }

    // public function updatetoolWatch($unitID , $toolWatch)
    // {
    //     DB::table('devices')
    //         ->where('unitID', $unitID)
    //         ->update(['toolWatch' => $toolWatch]);
    // }

    public function updateDeviceActivateDate($unitID , $unitActivateDate)
    {
        DB::table('devices')
            ->where('unitID', $unitID)
            ->update(['activateDate' => $unitActivateDate]);
    }

    public function updateDeviceOperator($unitID , $unitOperator)
    {
        DB::table('devices')
            ->where('unitID', $unitID)
            ->update(['operator' => $unitOperator]);
    }

    public function updateDeviceAddress($unitID , $unitAddress)
    {
        DB::table('devices')
            ->where('unitID', $unitID)
            ->update(['address' => $unitAddress]);
    }

    public function updateAlert($unitID, $alert)
    {
        if($alert == 1){
            DB::table('devices')
            ->where('unitID', $unitID)
            ->update(['isAlert' => true]);
        }else{
            DB::table('devices')
            ->where('unitID', $unitID)
            ->update(['isAlert' => false]);
        }
        
    }

    public function getDeviceHistory($unitID)
    {
        return DB::table('histories')
            ->where('deviceID', $unitID)
            ->orderBy('id', 'DESC')
            ->take(15)
            ->get();
    }

    public function getDevice($unitID)
    {
        return DB::table('devices')
            ->where('unitID', $unitID)
            ->get();
    }
}
